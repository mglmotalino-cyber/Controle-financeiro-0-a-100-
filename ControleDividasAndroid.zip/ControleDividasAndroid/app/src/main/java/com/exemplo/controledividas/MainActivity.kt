package com.exemplo.controledividas

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import android.content.Context
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

private val Context.dataStore by preferencesDataStore("dividas")

@Serializable
data class Divida(
    val id: Long,
    val nome: String,
    val valorTotal: Double,
    val parcela: Double,
    val parcelasTotais: Int,
    val parcelasPagas: Int = 0
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

@Composable
fun App() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    var dividas by remember { mutableStateOf<List<Divida>>(emptyList()) }
    var mostrarCadastro by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        val key = stringPreferencesKey("lista")
        val raw = context.dataStore.data.first()[key]
        if (!raw.isNullOrBlank()) dividas = Json.decodeFromString(raw)
    }

    fun salvar(lista: List<Divida>) {
        dividas = lista
        scope.launch {
            context.dataStore.edit { it[stringPreferencesKey("lista")] = Json.encodeToString(lista) }
        }
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = Color(0xFF1565C0))) {
        Surface(Modifier.fillMaxSize()) {
            if (mostrarCadastro) {
                Cadastro(
                    onCancel = { mostrarCadastro = false },
                    onSave = { d -> salvar(dividas + d); mostrarCadastro = false }
                )
            } else {
                Dashboard(dividas, onAdd = { mostrarCadastro = true }) { id ->
                    salvar(dividas.map { if (it.id == id) it.copy(parcelasPagas = (it.parcelasPagas + 1).coerceAtMost(it.parcelasTotais)) else it })
                }
            }
        }
    }
}

@Composable
fun Dashboard(dividas: List<Divida>, onAdd: () -> Unit, onPay: (Long) -> Unit) {
    val total = dividas.sumOf { it.valorTotal }
    val pago = dividas.sumOf { it.parcela * it.parcelasPagas }
    val restante = (total - pago).coerceAtLeast(0.0)
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Controle de Dívidas", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFFE3F2FD))) {
            Column(Modifier.padding(18.dp)) {
                Text("Total das dívidas", fontWeight = FontWeight.Bold)
                Text("R$ %.2f".format(total), color = Color(0xFFC62828), style = MaterialTheme.typography.headlineSmall)
                Text("Restante: R$ %.2f".format(restante), color = Color(0xFF2E7D32))
                Spacer(Modifier.height(8.dp))
                LinearProgressIndicator(
                    progress = { if (total > 0) (pago / total).toFloat().coerceIn(0f,1f) else 0f },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
        Spacer(Modifier.height(14.dp))
        Button(onClick = onAdd, modifier = Modifier.fillMaxWidth()) { Text("Adicionar dívida") }
        Spacer(Modifier.height(10.dp))
        if (dividas.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Nenhuma dívida cadastrada.") }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(dividas, key = { it.id }) { d ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp)) {
                            Text(d.nome, fontWeight = FontWeight.Bold)
                            Text("Parcela: R$ %.2f".format(d.parcela))
                            Text("Pago: ${d.parcelasPagas}/${d.parcelasTotais}")
                            val p = if (d.parcelasTotais > 0) d.parcelasPagas.toFloat()/d.parcelasTotais else 0f
                            LinearProgressIndicator(progress = { p }, modifier = Modifier.fillMaxWidth().padding(vertical=6.dp))
                            OutlinedButton(onClick = { onPay(d.id) }) {
                                Text(if (d.parcelasPagas < d.parcelasTotais) "Marcar próxima parcela como paga" else "Quitada")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun Cadastro(onCancel: () -> Unit, onSave: (Divida) -> Unit) {
    var nome by remember { mutableStateOf("") }
    var total by remember { mutableStateOf("") }
    var parcela by remember { mutableStateOf("") }
    var qtd by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("Nova dívida", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(14.dp))
        OutlinedTextField(nome, { nome = it }, label = { Text("Nome da dívida") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(total, { total = it }, label = { Text("Valor total") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(parcela, { parcela = it }, label = { Text("Valor da parcela") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(qtd, { qtd = it }, label = { Text("Quantidade de parcelas") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(18.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton(onClick = onCancel, modifier = Modifier.weight(1f)) { Text("Cancelar") }
            Button(
                onClick = {
                    val t = total.replace(",", ".").toDoubleOrNull() ?: 0.0
                    val p = parcela.replace(",", ".").toDoubleOrNull() ?: 0.0
                    val n = qtd.toIntOrNull() ?: 0
                    if (nome.isNotBlank() && t > 0 && p > 0 && n > 0) {
                        onSave(Divida(System.currentTimeMillis(), nome, t, p, n))
                    }
                },
                modifier = Modifier.weight(1f)
            ) { Text("Salvar") }
        }
    }
}
