# Controle de Dívidas — Android

Projeto inicial em Kotlin + Jetpack Compose.

## Recursos
- Cadastro de dívidas
- Valor total e valor da parcela
- Controle de parcelas pagas
- Barra de progresso
- Resumo total/restante
- Persistência local com DataStore
- Interface arredondada em tons de azul
- Dívidas em vermelho e progresso positivo em verde

## Como gerar o APK
Abra a pasta no Android Studio, aguarde a sincronização do Gradle e use:
Build > Build APK(s)

O APK de debug normalmente fica em:
app/build/outputs/apk/debug/app-debug.apk

## Próxima evolução
Calendário de vencimentos, edição/exclusão, gráficos, notificações e acompanhamento mensal.
